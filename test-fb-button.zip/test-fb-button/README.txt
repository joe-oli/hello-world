#0. Ensure your computer has node.js installed (I am running on v8.12, on Windows 10)

#1. cd \test-fb-button AND THEN npm install

to install the http-server package. 


#2. start the server with following command

http-server --ssl -c-1

Starting up http-server, serving ./public through https
Available on:
  https://10.2.15.174:8080
  https://127.0.0.1:8080
Hit CTRL-C to stop the server


#3. Navigate to https:localhost:8080

This will serve the /public/index.html page, with the fb-login-button

Hit F12 to see the Browser console. (I am using Chrome)



#4. Click on `Log in With Facebook`

The Facebook Login Popup shows. After you login, it calls back to my local server page index.html

You will see in the console that it FIRES TWICE <== THIS IS THE ERROR. IT SHOULD ONLY FIRE ONCE.




Results in console:
-------------------
callback_afterLogin: {authResponse: {…}, status: "connected"}

ERROR MSG:
You are overriding current access token, that means some other app is expecting different access token and you will probably break things. Please consider passing access_token directly to API parameters instead of overriding the global settings.

callback_afterLogin: {authResponse: {…}, status: "connected"}

